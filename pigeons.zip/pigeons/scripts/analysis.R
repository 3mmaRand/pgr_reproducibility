library(tidyverse)

# import processed data
# wd
# "C:/Users/er13/Desktop/pigeons"
pigeon <- read_table2("data-processed/pigeon_long.txt")

# summarise
pigeon %>% 
  group_by(population) %>% 
  summarise(mean = mean(distance),
            n = length(distance),
            sd = sd(distance),
            se = sd/sqrt(n))

# plot
p <- ggplot(data = pigeon, aes(x = population, y = distance)) + 
  geom_boxplot() +                            
  scale_x_discrete(name = "Population") +
  scale_y_continuous(name = "Interorbital distance (mm)",
                     expand = c(0, 0),
                     limits = c(0, 15)) +
  theme_classic()

# write plot to file
# figure saving settings
units <- "in"  
fig_w <- 3.2
fig_h <- fig_w
dpi <- 300
device <- "tiff"

ggsave("figures/fig1.tiff",
       plot = p,
       device = device,
       width = fig_w,
       height = fig_h,
       units = units,
       dpi = dpi)