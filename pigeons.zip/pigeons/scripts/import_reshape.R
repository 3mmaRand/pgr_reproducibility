# packages
library(tidyverse)

# import
# wd
# "C:/Users/er13/Desktop/pigeons"
pigeon <- read_table2("data-raw/pigeon.txt")

# if wd set to location of script file
# # "C:/Users/er13/Desktop/pigeons/scripts"
# pigeon <- read_table2("../data-raw/pigeon.txt")

# note when we use projects we will see that the project directory is "pigeons" and that it is good practice to have your wd as the project directory.

str(pigeon)
# is formatted in wide format. we will tidy into long format
# tidy
pigeon2 <- pivot_longer(data = pigeon, 
                        cols = everything(), 
                        names_to = "population", 
                        values_to = "distance")
str(pigeon2)
# write tidy data to file
file <- "data-processed/pigeon_long.txt"
write_delim(pigeon2, file)
